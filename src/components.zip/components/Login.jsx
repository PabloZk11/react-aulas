import React from "react";
import { Link } from 'react-router-dom';
import './css/Login.css';

const Login = () => {
  return (
    <div className="simula-body">
      <nav className="navbar" style={{ backgroundColor: '#a72c2c' }}>
        <div className="container-fluid">
          <a className="navbar-brand" href="index.html">
            <img src="./img/logo.png" alt="Logo" width={300} height={120} className="d-inline-block align-text-top" />
          </a>
        </div>
      </nav>
      <div className="container">
        <Link to="/Indexven" className="boton-esquina">Ingresar como Vendedor</Link>
        <div id="container">
          <div className="form-container sign-up" />
          <div className="form-container sign-in">
            <form>
              <h1>Ingresar</h1>
              <input type="email" placeholder="Email" />
              <input type="password" placeholder="Contraseña" />
              <input type="text" placeholder="Codigo" /> {/* Añadí el atributo type="text" */}
              <Link to="/admin/index-admin.html"><button>Ingresar</button></Link> {/* Usando Link */}
            </form>
          </div>
          <div className="toggle-container">
            <div className="toggle">
              <div className="toggle-panel toggle-right">
                <h1>Bienvenido Administrador</h1>
                <p>¡Espero este teniendo un buen día!</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="pqrs">
        <a href="pqrs.html"><i className="fa-solid fa-circle-exclamation fa-beat" /></a>
      </div>
      <footer id="foot">
        <small id="derechos">© 2024  <b>Aulas</b> - todos los derechos reservados</small>
      </footer>
    </div>
  );
}

export default Login;
